import React from 'react';
import fractalLoop from '../assets/fractal-loop.mp4'; // Importar o vídeo

const Main = () => {
  return (
    <div className="main">
      <video autoPlay loop muted className="video-background">
        <source src={fractalLoop} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="content">
        <h1>Welcome</h1>
        <p>To my site</p>
      </div>
    </div>
  );
};

export default Main;